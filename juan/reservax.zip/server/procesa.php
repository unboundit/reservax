<?php     
    include("db.php");
    $persons = $_POST['person'];
    $hour = $_POST['hour'];
    $minute = $_POST['min'];
    $date = $_POST['date'];
    $first_name = $_POST['fName'];
    $last_name = $_POST['lName'];
    $email_from = $_POST['email'];
    $telephone = $_POST['phone'];
    $negocio = $_POST['negocio'];
    $fecha_reserva = date('Y-m-d',$date);
    $hora_llegada = strtotime($hour.":".$min);

    $email_to = "a.tello@unbound-it.com, ".$email_from;
    $email_subject = "Reservacion";

    conectar();
    $consultaSQL = "INSERT INTO reservaciones VALUES (null,$negocio,'$first_name','$last_name','$telephone','$email_from','',$persons,'$fecha_reserva')";
    $query = mysql_query($consultaSQL, $this->coneccion);

 

 

    $email_message = "<html>

                        <head>

                        </head>
                        <body>
                        <table style='width: 100%; height: 100%;'>
                          <tbody>
                            <tr>
                              <td>Encabezado</td>
                            </tr>
                            <tr>
                              <td>
                                <table style='margin: 0 auto;'>
                                  <tbody>
                                    <tr>
                                      <td>Datos de Cliente</td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td>Nombre: </td>
                                      <td>".$first_name."</td>
                                    </tr>
                                    <tr>
                                      <td>Apellidos: </td>
                                      <td>".$last_name."</td>
                                    </tr>
                                    <tr>
                                      <td>Email: </td>
                                      <td>".$email_from."</td>
                                    </tr>
                                    <tr>
                                      <td>Fecha Entrada: </td>
                                      <td>".$checkIN."</td>
                                    </tr>
                                    <tr>
                                      <td>Fecha Salida: </td>
                                      <td>".$checkOut."</td>
                                    </tr>
                                    <tr>
                                      <td>Adultos: </td>
                                      <td>".$adults."</td>
                                    </tr>
                                    <tr>
                                      <td>Ni&ntilde;os: </td>
                                      <td>".$child."</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                            <tr style='background-color: yellow;'>
                              <td>Pie Mail</td>
                            </tr>
                          </tbody>
                        </table>
                        <div style='background-color: yellow; width: 50px; height: 50px;'></div>
                        <div style='background-color: blue; width: 50px; height: 50px;'></div>
                        <div style='background-color: red; width: 50px; height: 50px;'></div>
                        </body>
                        </html>";

// create email headers

 
$headers = "From: ".$email_from."\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=utf-8\r\n";
$headers .= "Content-Transfer-Encoding: 8bit\r\n";

  if (mail($email_to, $email_subject, $email_message, $headers))
  {   
    echo("<p>Gracias por reservar con nosotros !</p>");
  }else 
  {   
    echo("<p>Lo Sentimos hubo un error en el servidor intente de nuevo</p>");
  } 

?>

