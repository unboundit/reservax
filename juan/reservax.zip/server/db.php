<?php
    public $coneccion;
    
    /* Metodo encargado de cnectar a la base de datos */
    public function conectar() {
        if (!isset($this->coneccion)) {
            $this->coneccion = (mysql_connect("localhost", "unboundi_abel", "ubit_abel")) or die(mysql_error());
            mysql_select_db("unboundi_reservax", $this->coneccion) or die(mysql_error());
        }
    }
       
      
      /* METODO PARADESCONECTAR DE LA BASE DE DATOS */
      public function desconectar() {
          mysql_close($this->coneccion);
      }

?>